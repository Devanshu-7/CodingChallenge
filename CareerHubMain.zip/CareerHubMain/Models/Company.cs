﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareerHubApp.Models
{
    public class Company
    {
        //Attributes for company
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
        public string Location { get; set; }

    }
}
